#include <jni.h>

#include <thread>

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <unistd.h>

#include "config.h"
#include "image_refocus.h"
#include "utils.h"

extern "C" { void* __dso_handle = 0;}

using std::thread;

JavaVM* g_jvm;
JNIEnv* g_jenv;

const int LONG_DELAY = 3500; // 3.5 seconds           
const int SHORT_DELAY = 2000; // 2 seconds
    
jobject getContext(JNIEnv* env, JavaVM* vm)
{
    jclass activityThread = env->FindClass("android/app/ActivityThread");
    jmethodID currentActivityThread = env->GetStaticMethodID(activityThread, "currentActivityThread", "()Landroid/app/ActivityThread;");
    jobject at = env->CallStaticObjectMethod(activityThread, currentActivityThread);
    jmethodID getApplication = env->GetMethodID(activityThread, "getApplication", "()Landroid/app/Application;");
    jobject context = env->CallObjectMethod(at, getApplication);
    
    return context;
}

void realtoast(JavaVM* vm, JNIEnv* env, const char* str, jint time)
{
    jobject context = getContext(env, vm);
    jclass tclss = env->FindClass("android/widget/Toast");
    jmethodID mid = env->GetStaticMethodID(tclss, "makeText", "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
    
    jclass loopclss = env->FindClass("android/os/Looper");
    jmethodID loopmid = env->GetStaticMethodID(loopclss, "prepare", "()V");
        
    env->CallStaticVoidMethod(loopclss, loopmid);
    
    jobject job = env->CallStaticObjectMethod(tclss, mid, context, env->NewStringUTF(str), time);
    jmethodID showId = env->GetMethodID(tclss, "show", "()V");
            
    env->CallVoidMethod(job, showId);
    
    
    log("xxxxxxxxxxxxxx before loop000");
    jmethodID loopmid2 = env->GetStaticMethodID(loopclss, "loop", "()V");


    thread t([](JNIEnv* env, jclass loopclss, jmethodID loopmid2){


        env->CallStaticVoidMethod(loopclss, loopmid2);
    }, env, loopclss, loopmid2);

    //jmethodID loopmid3 = env->GetStaticMethodID(loopclss, "quit", "()V");
    //env->CallStaticVoidMethod(loopclss, loopmid3);
    
    log("xxxxxxxxxxxxxx after quit");
        
    t.join();
    
    log("xxxxxxxxxxxxxx after loop");
}

void toast(const char* str)
{
    realtoast(g_jvm, g_jenv, str, LONG_DELAY);
}

JNIEXPORT jlong nativeInit(JNIEnv* env, jobject obj, jint focusMode)
{
    ImageFocus* e = new ImageFocus;
    
    e->init(focusMode);
    
    g_jenv = env;
    
    return (jlong)e;
}

JNIEXPORT jint nativeSetCalibrationData(JNIEnv* env, jobject obj, jlong engine, jbyteArray data)
{
    ImageFocus* e = (ImageFocus*)engine;
    
    jbyte* arr = env->GetByteArrayElements(data, NULL);
    jint length = env->GetArrayLength(data);

    log("nativeSetCalibrationData data length is %d", length);
    
    e->setCaldata(arr, length);
    
    env->ReleaseByteArrayElements(data, arr, 0);
        
    return 0;
}

JNIEXPORT jint nativeSetImgDegree(JNIEnv* env, jobject obj, jlong engine, jint degree)
{
    ImageFocus* e = (ImageFocus*)engine;
    
    e->setImgDegree(degree);
    
    char t[256];
    sprintf(t, "image degree is %d", degree);
    
    toast(t);
    toast(t);
    
    return 0;
}

JNIEXPORT jint nativeSetMaxFov(JNIEnv* env, jobject obj, jlong engine, jfloat maxFov)
{
    ImageFocus* e = (ImageFocus*)engine;
    
    e->setMaxFov(maxFov);
    
    return 0;
}

JNIEXPORT jint nativeSetCameraImageInfo(JNIEnv* env, jobject obj, jlong engine, jint leftWidth, jint leftHeight, jint rightWidth, jint rightHeight)
{
    ImageFocus* e = (ImageFocus*)engine;
    
    e->setCameraImageInfo(leftWidth, leftHeight, rightWidth, rightHeight);
    
    return 0;
}

JNIEXPORT jint nativeSetFaceParam(JNIEnv* env, jobject obj, jlong engine, jintArray faceRects, jintArray faceAngles)
{
    ImageFocus* e = (ImageFocus*)engine;
    
    jint length = env->GetArrayLength(faceAngles);

    // hard code now to ease work
    static MRECT st_faces[32];
    static MInt32 st_faceAngles[32];
    if(length > 32) return -1;
    
    jint* rects = env->GetIntArrayElements(faceRects, NULL);
    jint* angles = env->GetIntArrayElements(faceAngles, NULL);
    
    memcpy(st_faces, rects, length * sizeof(MRECT));
    memcpy(st_faceAngles, angles, length * sizeof(MInt32));
    
    e->setFaceParam(st_faces, st_faceAngles, length);
    
    env->ReleaseIntArrayElements(faceRects, rects, 0);
    env->ReleaseIntArrayElements(faceAngles, angles, 0);
    
    return 0;
}

JNIEXPORT jint nativeCalcDisparityMap(JNIEnv* env, jobject obj, jlong engine,
                                      jbyteArray leftImg, jint leftImgWidth, jint leftImgHeight,
                                      jint leftImgStride, jint leftImgScanline,
                                      jbyteArray rightImg, jint rightImgWidth, jint rightImgHeight,
                                      jint rightImgStride, jint rightImgScanline)
{
    ImageFocus* e = (ImageFocus*)engine;

    jbyte* left_data  = env->GetByteArrayElements(leftImg, NULL);
    jbyte* right_data = env->GetByteArrayElements(rightImg, NULL);

    ASVLOFFSCREEN imgLeft  = {0};
	ASVLOFFSCREEN imgRight = {0};

    int imgLeft_uv_offset = leftImgStride*leftImgScanline;

    imgLeft.u32PixelArrayFormat  = ASVL_PAF_NV21;
    imgLeft.i32Width             = leftImgWidth;
    imgLeft.i32Height            = leftImgHeight;
    imgLeft.ppu8Plane[0]         = (unsigned char*)left_data;
    imgLeft.ppu8Plane[1]         = imgLeft.ppu8Plane[0] + imgLeft_uv_offset;
    imgLeft.ppu8Plane[2]         = 0;
    imgLeft.pi32Pitch[0]         = leftImgStride;
    imgLeft.pi32Pitch[1]         = leftImgStride;
    imgLeft.pi32Pitch[2]         = leftImgStride;

    int imgRight_uv_offset = rightImgStride * rightImgScanline;

    imgRight.u32PixelArrayFormat = ASVL_PAF_NV21;
    imgRight.i32Width            = rightImgWidth;
    imgRight.i32Height           = rightImgHeight;
    imgRight.ppu8Plane[0]        = (unsigned char*)right_data;
    imgRight.ppu8Plane[1]        = imgRight.ppu8Plane[0] + imgRight_uv_offset;
    imgRight.ppu8Plane[2]        = 0;
    imgRight.pi32Pitch[0]        = rightImgStride;
    imgRight.pi32Pitch[1]        = rightImgStride;
    imgRight.pi32Pitch[2]        = rightImgStride;

    log("left image left_data: %p, width: %d, heigh: %d, stride: %d, scanline: %d",
            left_data, leftImgWidth, leftImgHeight, leftImgStride, leftImgScanline);
    log("right image right_data: %p,  width: %d, heigh: %d, stride: %d, scanline: %d",
            right_data, rightImgWidth, rightImgHeight, rightImgStride, rightImgScanline);

#ifdef CAMERA_DEBUG_DUMP_FILE

    dumpOffscreen2File(&imgLeft, "IMG_0", "capture_left");
    dumpOffscreen2File(&imgRight, "IMG_1", "capture_right");

#endif

    e->calcDispMap(imgLeft, imgRight);

    env->ReleaseByteArrayElements(leftImg, left_data, 0);
    env->ReleaseByteArrayElements(rightImg, right_data, 0);
    
    return 0;
}

JNIEXPORT jint nativeSetFocusPoint(JNIEnv * env, jobject obj, jlong engine, jint x, jint y)
{
    ImageFocus* e = (ImageFocus*)engine;
    
    MPOINT p = {x, y};
    e->setFocusPoint(p);
    
    return 0;
}

JNIEXPORT jint nativeSetBlurIntensity(JNIEnv * env, jobject obj, jlong engine, jint blurIntensity)
{
    ImageFocus* e = (ImageFocus*)engine;
    
    e->setBlurIntensity(blurIntensity);
    
    return 0;
}

JNIEXPORT jint nativeProcessGetNV21(JNIEnv * env, jobject obj, jlong engine,
                                    jbyteArray leftImg, jint leftImgWidth, jint leftImgHeight,
                                    jint leftImgStride, jint leftImgScanline,
                                    jbyteArray dstImg, jint dstImgWidth, jint dstImgHeight)
{
    ImageFocus* e = (ImageFocus*)engine;
    
    jbyte* dst_data = env->GetByteArrayElements(dstImg, NULL);

    jbyte* left_data = env->GetByteArrayElements(leftImg, NULL);

    ASVLOFFSCREEN imgLeft = {0};
    ASVLOFFSCREEN imgDst  = {0};

    int imgLeft_uv_offset = leftImgStride*leftImgScanline;

    imgLeft.u32PixelArrayFormat  = ASVL_PAF_NV21;
    imgLeft.i32Width             = leftImgWidth;
    imgLeft.i32Height            = leftImgHeight;
    imgLeft.ppu8Plane[0]         = (unsigned char*)left_data;
    imgLeft.ppu8Plane[1]         = imgLeft.ppu8Plane[0] + imgLeft_uv_offset;
    imgLeft.ppu8Plane[2]         = 0;
    imgLeft.pi32Pitch[0]         = leftImgStride;
    imgLeft.pi32Pitch[1]         = leftImgStride;
    imgLeft.pi32Pitch[2]         = leftImgStride;

    imgDst.u32PixelArrayFormat   = ASVL_PAF_NV21;
    imgDst.i32Width              = dstImgWidth;
    imgDst.i32Height             = dstImgHeight;
    imgDst.ppu8Plane[0]          = (unsigned char*)dst_data;
    imgDst.ppu8Plane[1]          = imgDst.ppu8Plane[0] + imgDst.i32Width*imgDst.i32Height;
    imgDst.ppu8Plane[2]          = 0;
    imgDst.pi32Pitch[0]          = imgDst.i32Width;
    imgDst.pi32Pitch[1]          = imgDst.i32Width;
    imgDst.pi32Pitch[2]          = imgDst.i32Width;
    
    e->process(imgLeft, imgDst);

#ifdef CAMERA_DEBUG_DUMP_FILE
    
    dumpOffscreen2File(&imgDst, "IMG_2", "capture_dst");

#endif
    
    env->ReleaseByteArrayElements(dstImg, dst_data, 0);
    env->ReleaseByteArrayElements(leftImg, left_data, 0);
    
    return 0;
}

JNIEXPORT jint nativeUnit(JNIEnv * env, jobject obj, jlong engine)
{
    ImageFocus* e = (ImageFocus*)engine;

    delete e;

    return 0;
}

int get_nv21_from_jpeg(unsigned char* jpeg, int jpegSize, unsigned char* nv21_data);

JNIEXPORT jint nativeConvertJpeg2NV21(JNIEnv* env, jobject obj, jbyteArray jpegdata, jbyteArray nv21)
{
    jbyte* jpeg = env->GetByteArrayElements(jpegdata, NULL);
    jint jpegSize = env->GetArrayLength(jpegdata);
        
    jbyte* nv21_data = env->GetByteArrayElements(nv21, NULL);
    
    get_nv21_from_jpeg((unsigned char*)jpeg, jpegSize, (unsigned char*)nv21_data);
    
    env->ReleaseByteArrayElements(jpegdata, jpeg, 0);
        
    return 0;
}

const char* const Java_class = "com/arcsoft/ImageRefocus/ImageRefocus";

static JNINativeMethod gMethods[] = {
    {"nativeInit", "(I)J", (void*) nativeInit},
    {"nativeSetCalibrationData", "(J[B)I", (void*) nativeSetCalibrationData},
    {"nativeSetImgDegree", "(JI)I", (void*) nativeSetImgDegree},
    {"nativeSetMaxFov", "(JF)I", (void*) nativeSetMaxFov},
    {"nativeSetFaceParam", "(J[I[I)I", (void*) nativeSetFaceParam},
    {"nativeCalcDisparityMap", "(J[BIIII[BIIII)I", (void*)nativeCalcDisparityMap},
    {"nativeSetFocusPoint","(JII)I", (void*) nativeSetFocusPoint},
    {"nativeSetBlurIntensity", "(JI)I", (void*) nativeSetBlurIntensity},
    {"nativeProcessGetNV21", "(J[BIIII[BII)I", (void*) nativeProcessGetNV21},
    {"nativeUnit", "(J)I", (void*) nativeUnit},
    {"nativeConvertJpeg2NV21", "([B[B)I", (void*) nativeConvertJpeg2NV21},
    {"nativeSetCameraImageInfo", "(JIIII)I", (void*) nativeSetCameraImageInfo},
	
};

static int RegisterNativeMethods(JNIEnv* env, const char* className,
                                 JNINativeMethod* gMethods, int numMethods)
{
    jclass clazz;
    clazz = env->FindClass(className);
    if (clazz == MNull)
    {
        return JNI_FALSE;
    }
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0)
    {
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

static void UnregisterNativeMethods(JNIEnv* env, const char* className)
{
    jclass clazz;
    clazz = env->FindClass(className);

    if(clazz == MNull)
        return;

    if(MNull != env)
    {
        env->UnregisterNatives(clazz);
    }
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved)
{
    JNIEnv* env = NULL;

    if(vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK)
    {
        return -1;
    }
    
    jint ret = RegisterNativeMethods(env, Java_class, gMethods,
            sizeof(gMethods) / sizeof(gMethods[0]));

    if(ret != JNI_TRUE)
    {
        return -1;
    }
    
    g_jvm = vm;
    
    return JNI_VERSION_1_4;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM* vm, void* reserved)
{
    JNIEnv* env = MNull;
    if(vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK)
        return;

    UnregisterNativeMethods(env, Java_class);
}
